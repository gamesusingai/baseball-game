
# BATTING CHALLENGE

Python + Pygame-CEで開発した2D野球バッティングゲームです。
Pygbagを使ってブラウザ上で動かすことを目指しています。

## 必要環境

- Python 3.11系を推奨
- Pygame-CE
- Pygbag
- Windows 10/11
- Google Chromeなどのモダンブラウザ

## インストール

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

## Windowsで起動

```powershell
python main.py
```

## ブラウザで動作確認

プロジェクトのルートフォルダで実行します。

```powershell
python -m pygbag .
```

ターミナルに表示されるローカルURLをブラウザで開いてください。

## 操作方法

- SPACE：スイング
- マウスクリック：スイング、ボタン操作
- ESC：タイトルへ戻る、または終了

## 主な機能

- タイトル画面
- 投球アニメーション
- タイミングによる打撃判定
- ストライク・ボール・三振
- ヒット・二塁打・ホームラン
- 得点・打撃結果の表示
- 3アウトでゲーム終了
- リトライ

## 注意

ブラウザ版では、Pygbagの対応状況やブラウザ環境によって
フォント表示や入力の挙動が異なる場合があります。

ブラウザ公開前に、ローカルのPygbagサーバーで
操作・表示・ゲーム進行を確認してください。
