
import asyncio
import math
import random
import pygame
import time

# ============================================================
# BATTING CHALLENGE
# Python + Pygame-CE + Pygbag
# ============================================================

# 設定
WIDTH = 960
HEIGHT = 540
FPS = 60

# Colors
SKY = (115, 190, 235)
GRASS = (52, 145, 76)
GRASS_DARK = (38, 119, 62)
DIRT = (184, 124, 72)
WHITE = (250, 250, 245)
BLACK = (25, 30, 35)
NAVY = (27, 48, 82)
YELLOW = (255, 220, 70)
RED = (220, 65, 65)
BLUE = (65, 135, 225)
ORANGE = (245, 155, 55)

# Game states
TITLE = "title"
PITCHING = "pitching"
FLIGHT = "flight"
RESULT = "result"
GAME_OVER = "game_over"



pygame.init()

# Logical canvas: keep the game layout stable when resized.
canvas = pygame.Surface((WIDTH, HEIGHT))
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
pygame.display.set_caption("BATTING CHALLENGE")
clock = pygame.time.Clock()

# Japanese font fallback.
# If Japanese characters do not display in the browser build,
# bundle a Japanese font inside the project and load it here.
def make_font(size, bold=False):
    for name in ("meiryo", "Yu Gothic", "Noto Sans CJK JP",
                 "msgothic", "sans"):
        try:
            font = pygame.font.SysFont(name, size, bold=bold)
            if font:
                return font
        except Exception:
            pass
    return pygame.font.Font(None, size)


FONT_SMALL = make_font(19)
FONT_MEDIUM = make_font(27, True)
FONT_LARGE = make_font(43, True)
FONT_TITLE = make_font(54, True)

# Buttons are defined in logical canvas coordinates.
START_BUTTON = pygame.Rect(350, 365, 260, 62)
RETRY_BUTTON = pygame.Rect(350, 350, 260, 58)
TITLE_BUTTON = pygame.Rect(350, 425, 260, 50)

# Game state
state = TITLE
Picher_x = 480
Picher_y = 100
batter_x = 430
batter_y = 400
ball_x = Picher_x # ボールの初期位置
ball_y = Picher_y # ボールの初期位置
pitch_start_time = 0.0 # 投球開始時間
pitch_duration = 1.45 # 投球時間
swing_used = False # スイング使用フラグ
result_timer = 0.0 # 結果表示タイマー
result_text = "" # 結果テキスト
result_color = WHITE # 結果テキストの色
last_distance = 0
last_timing = 0.0

balls = 0 # ボール数
strikes = 0 # スライク数
outs = 0 # アウト数
score = 0 # スコア
hits = 0 # ヒット数
home_runs = 0 # ホームラン数
at_bats = 0 # 打席数
message = "" # メッセージ
game_time = 0.0

# Base paths
top = (Picher_x, 80)
right = (Picher_x + 350, Picher_y + 50)
bottom = (Picher_x, batter_y)
left = (Picher_x - 350, Picher_y + 50)

# スイング
is_swinging = False # バッターがスイング中かどうか
swing_pending = False # スイングが保留されているかどうか
swing_judged = False
is_charging = False  # バットを構えているか
SWING_CONTACT_TIME = 150 # スイング判定のタイミング（ミリ秒）
swing_start_time = 0 # スイングを開始した時刻（ミリ秒）
SWING_DURATION = 300 # スイングの継続時間（ミリ秒）
bat_angle = -60 # バットの角度（度）

# The ball should be hit near this x-coordinate.
HIT_Y = 400 # ヒットするべきy座標


def reset_game():
    """Reset the complete game."""
    global is_charging
    global at_bats, message, game_time
    global is_swinging, swing_pending, swing_judged, bat_angle
    global state, ball_x, ball_y, pitch_start_time
    global swing_used, result_timer, result_text, result_color
    global last_distance, last_timing
    global balls, strikes, outs, score, hits, home_runs
    global at_bats, message, game_time

    state = TITLE
    ball_x = Picher_x # ボールの初期位置
    ball_y = Picher_y # ボールの初期位置
    pitch_start_time = 0.0 # 投球開始時間
    swing_used = False # スイング使用フラグ
    result_timer = 0.0 # 結果表示タイマー
    result_text = "" # 結果テキスト
    result_color = WHITE # 結果テキストの色
    last_distance = 0 # 最後の距離
    last_timing = 0.0 # 最後の.timing
    is_swinging = False
    swing_pending = False
    swing_judged = False
    is_charging = False
    bat_angle = -60

    balls = 0 # ボール数
    strikes = 0 # スライク数
    outs = 0 # アウト数
    score = 0 # スコア
    hits = 0 # ヒット数
    home_runs = 0 # ホームラン数
    at_bats = 0 # 打席数
    message = "" # メッセージ
    game_time = 0.0


def start_pitch():
    """Start the next pitch."""
    global state, ball_x, ball_y, pitch_start_time
    global pitch_duration, swing_used

    state = PITCHING
    ball_x = Picher_x # ボールの初期位置
    ball_y = Picher_y # ボールの初期位置
    pitch_start_time = game_time # 投球開始時間
    pitch_duration = random.uniform(1.15, 1.55) # 投球時間
    swing_used = False # スイング使用フラグ


def finish_result(text, color=WHITE, distance=0, duration=1.25):
    """Display the result of the current pitch."""
    global state, result_text, result_color
    global result_timer, last_distance

    state = RESULT
    result_text = text
    result_color = color
    result_timer = duration
    last_distance = distance


def call_strike(text="ストライク！"):
    """Record a strike and handle a strikeout."""
    global strikes, outs, at_bats, balls, message

    strikes += 1

    if strikes >= 3:
        outs += 1
        at_bats += 1
        message = "三振！"

        # One strikeout ends the at-bat, not the whole game.
        balls = 0
        strikes = 0

        if outs >= 3:
            finish_result("三振！ 3アウト ゲーム終了", RED, duration=2.0)
            # Switch to game-over after showing the result.
            global next_state_after_result
            next_state_after_result = GAME_OVER
        else:
            finish_result("三振！ 次の打席へ", RED, duration=1.6)
            next_state_after_result = PITCHING
    else:
        message = text
        finish_result(text, YELLOW, duration=0.9)
        next_state_after_result = PITCHING


def call_ball():
    """Record a ball; four balls award a walk."""
    global balls, strikes, at_bats, message, score

    balls += 1

    if balls >= 4:
        at_bats += 1
        score += 1
        balls = 0
        strikes = 0
        message = "フォアボール！ 出塁！"
        finish_result(message, BLUE, duration=1.4)
    else:
        message = "ボール"
        finish_result(message, WHITE, duration=0.9)

    global next_state_after_result
    next_state_after_result = PITCHING

def start_charge():
    """ボタンやキーを押してバッターが構える。"""
    global is_charging, bat_angle

    if state != PITCHING or swing_used:
        return

    if is_swinging or is_charging:
        return

    is_charging = True
    bat_angle = -120

def release_swing():
    """ボタンやキーを離したときにスイングする。"""
    global is_charging

    if not is_charging:
        return

    is_charging = False
    swing_batter()

def swing_batter():
    """スイングを開始し、後で打撃判定を行う。"""
    global is_swinging, swing_start_time
    global swing_pending, swing_judged, bat_angle

    if is_swinging or state != PITCHING or swing_used:
        return

    is_swinging = True
    swing_pending = True
    swing_judged = False
    swing_start_time = pygame.time.get_ticks()

    # 構えの角度からスイングを開始
    bat_angle = -120

def update_swing():
    global is_swinging, bat_angle
    global swing_pending, swing_judged

    if not is_swinging:
        return

    elapsed = pygame.time.get_ticks() - swing_start_time

    # スイングの途中で打撃判定を行う
    if swing_pending and not swing_judged:
        if elapsed >= SWING_CONTACT_TIME:
            swing_pending = False
            swing_judged = True
            judge_swing()

    progress = min(elapsed / SWING_DURATION, 1.0)

    if progress < 0.7:
        phase = progress / 0.7
        # 構えた角度から前方へ振り抜く
        bat_angle = -120 + 210 * phase
    else:
        phase = (progress - 0.7) / 0.3
        # スイング後に構えの角度へ戻す
        bat_angle = 90 - 210 * phase

    if progress >= 1.0:
        time.sleep(1)  # スイング終了後に少し待つ
        is_swinging = False
        bat_angle = -60
        swing_judged = False

def judge_swing():
    """Judge swing timing based on distance from the ideal hit point."""
    global swing_used, last_timing, hits, home_runs
    global score, balls, strikes, at_bats, message

    if state != PITCHING or swing_used:
        return

    swing_used = True
    delta = ball_y - HIT_Y
    timing_error = abs(delta)
    last_timing = timing_error

    # A swing too early is recorded, but the pitch continues.
    if delta < -95:
        message = "早すぎ！"
        return

    # A swing too late is a strike.
    if delta > 95:
        call_strike("振り遅れ！ ストライク")
        return

    # Contact window: timing quality is between 0 and 1.
    quality = max(0.0, 1.0 - timing_error / 95.0) # タイミングの品質
    at_bats += 1

    # Great contact produces stronger results more often.
    roll = random.random() # ランダムな値を生成

    if quality >= 0.82 and roll < 0.38:
        home_runs += 1
        hits += 1
        score += 4
        distance = random.randint(105, 135)
        message = "ホームラン！！"
        finish_result(message, YELLOW, distance, 1.6)

    elif quality >= 0.60 and roll < 0.72:
        hits += 1
        score += 2
        distance = random.randint(70, 100)
        message = "二塁打！"
        finish_result(message, ORANGE, distance, 1.4)

    elif quality >= 0.30 and roll < 0.82:
        hits += 1
        score += 1
        distance = random.randint(35, 65)
        message = "ヒット！"
        finish_result(message, BLUE, distance, 1.2)

    elif quality >= 0.12 and roll < 0.90:
        # Weak contact is treated as a foul.
        message = "ファウル！"
        strikes = min(2, strikes + 1)
        finish_result(message, WHITE, random.randint(5, 25), 1.0)

    else:
        # Poor contact is an out.
        message = "打ち取られた！ アウト"
        global outs
        outs += 1

        if outs >= 3:
            finish_result("アウト！ 3アウト ゲーム終了", RED, duration=1.8)
            global next_state_after_result
            next_state_after_result = GAME_OVER
        else:
            finish_result("アウト！", RED, duration=1.2)
            next_state_after_result = PITCHING

    # A completed hit ends the at-bat; reset the count.
    balls = 0
    strikes = 0

    # Unless the result already specified a game-over transition,
    # proceed to the next pitch after the result display.
    if state == RESULT and "next_state_after_result" not in globals():
        next_state_after_result = PITCHING


next_state_after_result = PITCHING


def update_game(dt):
    """Update game state and animations."""
    global game_time, ball_x, ball_y, state
    global result_timer, next_state_after_result, message

    game_time += dt # ゲーム時間を更新

    if state == PITCHING:
        elapsed = game_time - pitch_start_time
        progress = min(1.0, elapsed / pitch_duration)

        # スイング判定が終わるまでは、投球を完全に終了させない
        if swing_pending and progress >= 1.0:
            progress = 0.98

        # Ease the ball toward the plate.
        ball_x = Picher_x
        ball_y = Picher_y + (HIT_Y - Picher_y) * progress

        if progress >= 1.0:
            if swing_used:
                # An early swing still becomes a strike at the plate.
                call_strike("空振り！ ストライク")
            else:
                # A take is randomly called a ball or a strike.
                if random.random() < 0.35:
                    call_ball()
                else:
                    call_strike("見逃しストライク")

    elif state == FLIGHT:
        # Reserved for future animated ball flight.
        pass

    elif state == RESULT:
        result_timer -= dt

        if result_timer <= 0:
            if next_state_after_result == GAME_OVER:
                state = GAME_OVER
            else:
                start_pitch()


def draw_text(surface, text, font, color, center):
    rendered = font.render(text, True, color)
    rect = rendered.get_rect(center=center)
    surface.blit(rendered, rect)


def draw_button(surface, rect, label, color=BLUE):
    pygame.draw.rect(surface, color, rect, border_radius=12)
    pygame.draw.rect(surface, WHITE, rect, 2, border_radius=12)
    draw_text(surface, label, FONT_MEDIUM, WHITE, rect.center)


def draw_field(surface):
    """Draw a simple stadium without external image files."""
    surface.fill(SKY)

    # Field
    pygame.draw.rect(surface, GRASS, (0, 50, WIDTH, 490))

    # Infield dirt
    pygame.draw.polygon(
        surface, DIRT,
        [top, right, bottom, left]
    )

    # Base paths
    pygame.draw.line(surface, WHITE, top, right, 3)
    pygame.draw.line(surface, WHITE, right, bottom, 3)
    pygame.draw.line(surface, WHITE, bottom, left, 3)
    pygame.draw.line(surface, WHITE, left, top, 3)

    # Bases
    for x, y in [top, right, bottom, left]:
        pygame.draw.rect(surface, WHITE, (x - 7, y - 7, 14, 14))


def draw_pitcher(surface, x, y, batter=False):
    """Draw a simple pitcher using geometric shapes."""
    # Legs
    pygame.draw.line(surface, WHITE, (x - 5, y + 24), (x - 10, y + 43), 6)
    pygame.draw.line(surface, WHITE, (x + 5, y + 24), (x + 10, y + 43), 6)

    # Body / uniform
    body_color = NAVY if batter else RED
    pygame.draw.rect(surface, body_color, (x - 13, y - 3, 26, 32),
                     border_radius=5)

    # Head and cap
    pygame.draw.circle(surface, (235, 185, 145), (x, y - 15), 12)
    pygame.draw.rect(surface, body_color, (x - 13, y - 29, 26, 7))
    pygame.draw.rect(surface, body_color, (x - 7, y - 35, 14, 8))

    if batter:
        # バットの支点
        pivot_x = x + 9
        pivot_y = y + 3

        # 角度をラジアンに変換する
        angle_rad = math.radians(bat_angle)

        # バットの長さ
        bat_length = 55

        # 角度に応じてバットの先端座標を計算する
        tip_x = pivot_x + math.cos(angle_rad) * bat_length
        tip_y = pivot_y + math.sin(angle_rad) * bat_length

        # 支点から先端までバットを描画する
        pygame.draw.line(
            surface,
            (115, 70, 35),
            (pivot_x, pivot_y),
            (int(tip_x), int(tip_y)),
            7
        )

def draw_batter(surface, x, y, batter=False):
    """構え・スイングに合わせて手足の位置を変えながら選手を描画する。"""
    skin = (235, 185, 145)
    pants = (240, 240, 235)
    jersey = NAVY if batter else RED
    shoes = (35, 35, 40)

    # pose: 0=通常、1=構え、スイング中は0→1→0へ変化
    pose = 0.0
    if batter:
        if is_charging:
            pose = 1.0
        elif is_swinging:
            elapsed = pygame.time.get_ticks() - swing_start_time
            progress = max(0.0, min(elapsed / SWING_DURATION, 1.0))
            # スイング前半で体を開き、後半で自然な姿勢に戻す
            if progress < 0.72:
                pose = progress / 0.72
            else:
                pose = (1.0 - progress) / 0.28
            pose = max(0.0, min(pose, 1.0))

    # 足：構えると膝を曲げ、足幅を広げる
    hip_l = (x - 9, y + 23)
    hip_r = (x + 9, y + 23)
    knee_l = (x - 17 - 3 * pose, y + 43 + 2 * pose)
    knee_r = (x + 18 + 5 * pose, y + 42 + 3 * pose)
    foot_l = (x - 27 - 5 * pose, y + 61)
    foot_r = (x + 29 + 8 * pose, y + 59)

    pygame.draw.line(surface, pants, hip_l, knee_l, 13)
    pygame.draw.line(surface, pants, hip_r, knee_r, 13)
    pygame.draw.line(surface, pants, knee_l, foot_l, 10)
    pygame.draw.line(surface, pants, knee_r, foot_r, 10)
    pygame.draw.circle(surface, pants, knee_l, 6)
    pygame.draw.circle(surface, pants, knee_r, 6)
    pygame.draw.ellipse(surface, shoes, (foot_l[0] - 8, foot_l[1] - 4, 17, 9))
    pygame.draw.ellipse(surface, shoes, (foot_r[0] - 8, foot_r[1] - 4, 17, 9))

    # 構え・スイング時は胴体を少し低く、前傾させる
    lean_x = 5 * pose
    shoulder_l = (x - 12 + lean_x, y - 4 + 2 * pose)
    shoulder_r = (x + 13 + lean_x, y - 7 + 2 * pose)
    waist_l = (x - 10, y + 24 + 2 * pose)
    waist_r = (x + 10, y + 24 + 2 * pose)
    neck = (x + 2 + lean_x, y - 10 + 2 * pose)

    pygame.draw.polygon(surface, jersey, [shoulder_l, shoulder_r, waist_r, waist_l])
    pygame.draw.line(surface, (25, 25, 35), shoulder_l, waist_l, 2)
    pygame.draw.line(surface, (25, 25, 35), shoulder_r, waist_r, 2)
    pygame.draw.line(surface, skin, neck, (x + 1 + lean_x, y - 1 + 2 * pose), 7)

    if batter:
        # 通常時の腕から、構えた腕の位置へ補間する
        shoulder_front = (x + 11 + lean_x, y - 5 + 2 * pose)
        elbow_front = (x + 22 + 2 * pose, y + 5 - 12 * pose)
        hand_front = (x + 12 - 10 * pose, y - 1 - 15 * pose)

        shoulder_back = (x - 10 + lean_x, y - 3 + 2 * pose)
        elbow_back = (x + 1 - 8 * pose, y + 10 - 12 * pose)
        hand_back = (x + 8 - 13 * pose, y + 2 - 16 * pose)

        # スイング中は手を前方へ動かす
        if is_swinging:
            elapsed = pygame.time.get_ticks() - swing_start_time
            progress = max(0.0, min(elapsed / SWING_DURATION, 1.0))
            swing_motion = math.sin(progress * math.pi)
            elbow_front = (elbow_front[0] + 22 * swing_motion,
                           elbow_front[1] + 5 * swing_motion)
            hand_front = (hand_front[0] + 34 * swing_motion,
                          hand_front[1] + 13 * swing_motion)
            elbow_back = (elbow_back[0] + 20 * swing_motion,
                          elbow_back[1] + 7 * swing_motion)
            hand_back = (hand_back[0] + 32 * swing_motion,
                         hand_back[1] + 14 * swing_motion)

        pygame.draw.line(surface, skin, shoulder_front, elbow_front, 8)
        pygame.draw.line(surface, skin, elbow_front, hand_front, 7)
        pygame.draw.line(surface, skin, shoulder_back, elbow_back, 8)
        pygame.draw.line(surface, skin, elbow_back, hand_back, 7)
        pygame.draw.circle(surface, skin, elbow_front, 4)
        pygame.draw.circle(surface, skin, elbow_back, 4)
        pygame.draw.circle(surface, skin, hand_front, 5)
        pygame.draw.circle(surface, skin, hand_back, 5)
    else:
        shoulder_l_arm = (x - 10, y - 4)
        elbow_l = (x - 17, y + 8)
        hand_l = (x - 4, y + 12)
        shoulder_r_arm = (x + 10, y - 4)
        elbow_r = (x + 16, y + 7)
        hand_r = (x + 4, y + 12)
        pygame.draw.line(surface, skin, shoulder_l_arm, elbow_l, 8)
        pygame.draw.line(surface, skin, elbow_l, hand_l, 7)
        pygame.draw.line(surface, skin, shoulder_r_arm, elbow_r, 8)
        pygame.draw.line(surface, skin, elbow_r, hand_r, 7)
        pygame.draw.circle(surface, skin, hand_l, 4)
        pygame.draw.circle(surface, skin, hand_r, 4)

    # 頭と帽子
    head_x = x + 3 + 2 * pose
    head_y = y - 19 + 2 * pose
    pygame.draw.circle(surface, skin, (int(head_x), int(head_y)), 11)
    pygame.draw.rect(surface, jersey, (int(head_x - 12), int(head_y - 12), 24, 5))
    pygame.draw.rect(surface, jersey, (int(head_x - 8), int(head_y - 18), 17, 8),
                     border_radius=3)

    # バット：両手の中間を支点にして、角度に合わせて描画
    if batter:
        if is_charging:
            angle = -120
        else:
            angle = bat_angle
        angle_rad = math.radians(angle)
        pivot_x = x + 8 - 7 * pose
        pivot_y = y - 1 - 14 * pose
        bat_length = 55
        tip_x = pivot_x + math.cos(angle_rad) * bat_length
        tip_y = pivot_y + math.sin(angle_rad) * bat_length
        pygame.draw.line(surface, (115, 70, 35),
                         (int(pivot_x), int(pivot_y)),
                         (int(tip_x), int(tip_y)), 7)

def draw_hud(surface):
    """Draw score and current baseball count."""
    pygame.draw.rect(surface, NAVY, (15, 15, 350, 76), border_radius=10)
    draw_text(surface, f"SCORE  {score}", FONT_MEDIUM, WHITE, (115, 40))
    draw_text(surface, f"HITS  {hits}    HR  {home_runs}",
              FONT_SMALL, WHITE, (185, 70))

    pygame.draw.rect(surface, NAVY, (720, 15, 225, 76), border_radius=10)
    draw_text(surface, f"OUT  {outs}/3", FONT_MEDIUM, WHITE, (832, 40))
    draw_text(surface, f"B {balls}   S {strikes}",
              FONT_MEDIUM, YELLOW, (832, 70))


def draw_timing_gauge(surface):
    """Draw the timing gauge during a pitch."""
    x, y, w, h = 300, 500, 360, 15
    pygame.draw.rect(surface, NAVY, (x, y, w, h), border_radius=7)

    # Ideal timing zone
    ideal_y = y + int((HIT_Y - 245) / (HIT_Y - 245) * h) - 18
    ideal_y = y + h // 2 - 28
    pygame.draw.rect(surface, GRASS, (x, ideal_y, w, 56), border_radius=5)

    # Ball indicator
    ratio = (ball_y - 245) / (HIT_Y - 245)
    marker_y = y + int(max(0, min(1, ratio)) * h)
    pygame.draw.circle(surface, YELLOW, (x + w // 2, marker_y), 9)

    draw_text(surface, "早い", FONT_SMALL, WHITE, (x - 35, y + 8))
    draw_text(surface, "遅い", FONT_SMALL, WHITE, (x + w + 35, y + 8))


def draw_title(surface):
    draw_field(surface)
    pygame.draw.rect(surface, NAVY, (160, 75, 640, 260), border_radius=22)
    pygame.draw.rect(surface, YELLOW, (160, 75, 640, 260), 4,
                     border_radius=22)

    draw_text(surface, "BATTING", FONT_TITLE, YELLOW, (480, 135))
    draw_text(surface, "CHALLENGE", FONT_TITLE, WHITE, (480, 192))
    draw_text(surface, "タイミングよくボールを打ち返そう！",
              FONT_MEDIUM, WHITE, (480, 250))
    draw_text(surface, "クリック / SPACEキー でスイング",
              FONT_SMALL, WHITE, (480, 292))

    draw_button(surface, START_BUTTON, "ゲームスタート", GRASS_DARK)


def draw_game(surface):
    draw_field(surface)
    draw_hud(surface)

    # Pitcher and batter
    draw_pitcher(surface, Picher_x, Picher_y, batter=False)
    draw_batter(surface, batter_x, batter_y, batter=True)

    # Strike zone
    pygame.draw.rect(surface, YELLOW, (Picher_x - 10, batter_y -20, 20, 40), 2)

    # Ball
    pygame.draw.circle(surface, WHITE, (int(ball_x), int(ball_y)), 10)
    pygame.draw.line(surface, RED,
                     (int(ball_x) - 5, int(ball_y) - 4),
                     (int(ball_x) + 5, int(ball_y) + 4), 2)

    if state == PITCHING:
        draw_timing_gauge(surface)
        draw_text(surface, "クリック / SPACE でスイング",
                  FONT_SMALL, WHITE, (480, 470))

        if message:
            draw_text(surface, message, FONT_MEDIUM, YELLOW, (480, 125))

    elif state == RESULT:
        # Result overlay
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 105))
        surface.blit(overlay, (0, 0))

        draw_text(surface, result_text, FONT_LARGE, result_color, (480, 230))

        if last_distance > 0:
            draw_text(surface, f"飛距離：{last_distance} m",
                      FONT_MEDIUM, WHITE, (480, 290))

        draw_text(surface, f"SCORE  {score}", FONT_MEDIUM, YELLOW, (480, 345))


def draw_game_over(surface):
    draw_field(surface)

    pygame.draw.rect(surface, NAVY, (180, 70, 600, 270), border_radius=20)
    pygame.draw.rect(surface, RED, (180, 70, 600, 270), 4,
                     border_radius=20)

    draw_text(surface, "GAME OVER", FONT_TITLE, RED, (480, 125))
    draw_text(surface, f"最終スコア：{score}", FONT_LARGE, YELLOW, (480, 190))
    draw_text(surface, f"ヒット：{hits}    ホームラン：{home_runs}",
              FONT_MEDIUM, WHITE, (480, 250))
    draw_text(surface, f"打席数：{at_bats}    アウト：{outs}",
              FONT_MEDIUM, WHITE, (480, 290))

    draw_button(surface, RETRY_BUTTON, "もう一度プレイ", BLUE)
    draw_button(surface, TITLE_BUTTON, "タイトルへ戻る", GRASS_DARK)


def draw_frame():
    """Draw the current screen to the logical canvas."""
    if state == TITLE:
        draw_title(canvas)
    elif state in (PITCHING, FLIGHT, RESULT):
        draw_game(canvas)
    elif state == GAME_OVER:
        draw_game_over(canvas)

    # Scale logical canvas to the actual window size.
    screen_size = screen.get_size()
    if screen_size[0] > 0 and screen_size[1] > 0:
        scaled = pygame.transform.smoothscale(canvas, screen_size)
        screen.blit(scaled, (0, 0))

    pygame.display.flip()


def to_logical_position(pos):
    """Convert mouse coordinates to logical canvas coordinates."""
    sw, sh = screen.get_size()
    if sw <= 0 or sh <= 0:
        return pos
    return (int(pos[0] * WIDTH / sw), int(pos[1] * HEIGHT / sh))


def handle_click(pos):
    global state

    x, y = pos

    if state == TITLE:
        if START_BUTTON.collidepoint(x, y):
            start_pitch()

    elif state == PITCHING:
        start_charge()

    elif state == GAME_OVER:
        if RETRY_BUTTON.collidepoint(x, y):
            reset_game()
            start_pitch()
        elif TITLE_BUTTON.collidepoint(x, y):
            reset_game()


async def main():
    global state

    running = True
    # ゲームループ
    while running:
        dt = min(clock.tick(FPS) / 1000.0, 0.05)

        for event in pygame.event.get():
            # Handle window events
            if event.type == pygame.QUIT:
                running = False

            # Handle window resize events
            elif event.type == pygame.VIDEORESIZE:
                # The logical canvas remains 960x540.
                screen = pygame.display.get_surface()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    handle_click(to_logical_position(event.pos))

            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1:
                    release_swing()

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    if state != TITLE:
                        reset_game()
                    else:
                        running = False

                elif event.key == pygame.K_SPACE:
                    if state == TITLE:
                        start_pitch()
                    elif state == PITCHING:
                        start_charge()
                    elif state == GAME_OVER:
                        reset_game()
                        start_pitch()

            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_SPACE:
                    release_swing()

        # スイングアニメーションと打撃判定を更新
        update_swing()
        # ボールやゲーム状態を更新
        update_game(dt)
        # 画面を描画
        draw_frame()

        # Required to yield control to the browser runtime in Pygbag.
        await asyncio.sleep(0)

    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
